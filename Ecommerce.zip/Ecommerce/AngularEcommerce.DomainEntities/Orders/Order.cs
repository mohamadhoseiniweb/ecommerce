﻿using System;
using System.Collections.Generic;
using AngularEcommerce.DomainEntities.Account;
using AngularEcommerce.DomainEntities.Common;

namespace AngularEcommerce.DomainEntities.Orders
{
    public class Order : BaseEntity
    {
        #region properties

        public long UserId { get; set; }

        public bool IsPay { get; set; }

        public DateTime? PaymentDate { get; set; }

        #endregion

        #region relations

        public User User { get; set; }

        public ICollection<OrderDetail> OrderDetails { get; set; }

        #endregion
    }
}
