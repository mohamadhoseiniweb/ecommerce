﻿namespace AngularEcommerce.Service.Security
{
    public interface IPasswordHelper
    {
        string EncodePasswordMd5(string password);
    }
}
