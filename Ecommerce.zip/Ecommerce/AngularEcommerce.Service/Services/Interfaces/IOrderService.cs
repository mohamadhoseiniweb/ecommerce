﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using AngularEcommerce.Service.DTOs.Orders;
using AngularEcommerce.DomainEntities.Orders;

namespace AngularEcommerce.Service.Services.Interfaces
{
    public interface IOrderService : IDisposable
    {
        #region order

        Task<Order> CreateUserOrder(long userId);
        Task<Order> GetUserOpenOrder(long userId);

        #endregion

        #region order detail

        Task AddProductToOrder(long userId, long productId, int count);
        Task<List<OrderDetail>> GetOrderDetails(long orderId);
        Task<List<OrderBasketDetail>> GetUserBasketDetails(long userId);
        Task DeleteOrderDetail(OrderDetail detail);

        #endregion
    }
}